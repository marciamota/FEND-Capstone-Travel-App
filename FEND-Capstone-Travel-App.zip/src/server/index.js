const app = require("./endpoints");

app.listen(8081, () => console.log(`Travel app listening on port 8081!`));
