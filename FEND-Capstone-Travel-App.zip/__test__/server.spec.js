import "babel-polyfill";
import { app } from '../src/server/index'

const request = require('supertest')

it('should route to index.html', async done => {
  const res = await request(app)
  .get('/')
  .send('../dist/index.html')
  expect(res.status).toBe(200)
  done()
})